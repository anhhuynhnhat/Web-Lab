/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.context;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author anhhnse61724
 */
public class DBContext {

    private static String serverName;
    private static String dbName;
    private static String portNumber;
    private static String userID;
    private static String password;
    private static String imageLink;

    static {
        try {
            InitialContext initialContext = new InitialContext();
            Context environmentContext = (Context) initialContext.lookup("java:comp/env");
            serverName = (String) environmentContext.lookup("serverName");
            dbName = (String) environmentContext.lookup("dbName");
            portNumber = (String) environmentContext.lookup("portNumber");
            userID = (String) environmentContext.lookup("userID");
            password = (String) environmentContext.lookup("password");
            imageLink = (String) environmentContext.lookup("imageLink");
        } catch (NamingException ex) {
            Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Connection getConnection() throws Exception {
        String url = "jdbc:sqlserver://" + serverName + ":" + portNumber + ";databaseName=" + dbName;
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        return DriverManager.getConnection(url, userID, password);
    }

    public String getResource() throws Exception {
        return imageLink;
    }

}
