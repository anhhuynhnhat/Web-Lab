/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.context.CloseConnection;
import com.context.DBContext;
import com.entity.Service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author anhhnse61724
 */
public class ServiceDetailsModel {

    DBContext db = new DBContext();
    CloseConnection close = new CloseConnection();
    //Query data from table Serivices where id = ?
    public Service getServicesByID(int ID) throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        Service bl = null;
        try {
            String sQuery = "SELECT * FROM services WHERE id = ?";
            con = db.getConnection();
            ps = con.prepareStatement(sQuery);
            ps.setInt(1, ID);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String des = rs.getString("description");
                String picture = db.getResource() + rs.getString("image");
                String sortDes = rs.getString("shortDes");
                int type = rs.getInt("type");
                bl = new Service(id, title, des, picture, sortDes, type);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            close.close(con, rs, ps);
        }
        return bl;
    }

}
