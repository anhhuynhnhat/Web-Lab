/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.context.CloseConnection;
import com.context.DBContext;
import com.entity.Home;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author anhhnse61724
 */
public class HomeModel {

    DBContext db = new DBContext();
    CloseConnection close = new CloseConnection();

    public ArrayList<Home> getListHomes() throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;

        Home bl = null;
        ArrayList<Home> arrHomes = new ArrayList<>();
        try {
            //Query data from table Home
            String sQuery = "SELECT * FROM Home";
            con = db.getConnection();
            ps = con.prepareStatement(sQuery);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String des = rs.getString("description");
                String picture = db.getResource() + rs.getString("image");
                String sortDes = rs.getString("shortDes");
                bl = new Home(id, title, des, picture, sortDes);
                arrHomes.add(bl);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            close.close(con, rs, ps);
        }
        return arrHomes;
    }

}
