/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.context.CloseConnection;
import com.context.DBContext;
import com.entity.Service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 *
 * @author anhhnse61724
 */
public class ServiceModel {

    DBContext db = new DBContext();
    CloseConnection close = new CloseConnection();

    public int getNumberOfItemOnPage() throws Exception {
        int numberOfItemOnPage;

        try {
            InitialContext intContext = new InitialContext();
            Context evnContext = (Context) intContext.lookup("java:comp/env");
            numberOfItemOnPage = Integer.parseInt((String) evnContext.lookup("numberOfItemOnPage"));
        } catch (Exception e) {
            throw e;
        }
        return numberOfItemOnPage;
    }

    public int getTotalPages() throws Exception {
        int totalPage = 0;
        int totalRecord = 0;
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        int pageSize = getNumberOfItemOnPage();
        try {
            //Query count TotalRecord from table services
            String squery = "SELECT COUNT(*) AS TotalRecord FROM services";
            con = db.getConnection();
            ps = con.prepareStatement(squery);
            rs = ps.executeQuery();
            while (rs.next()) {
                totalRecord = rs.getInt("TotalRecord");
            }
            //if totalRecord % 2 !=0
            if (totalRecord % pageSize != 0) {
                totalPage = (totalRecord / pageSize) + 1;
            } // totalRecord % 2
            else {
                totalPage = totalRecord / pageSize;
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            close.close(con, rs, ps);
        }
        return totalPage;
    }

    public ArrayList<Service> getDataList(int currentPage) throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        ArrayList<Service> returnList = new ArrayList<>();
        int pageSize = getNumberOfItemOnPage();
        int stat = (currentPage - 1) * pageSize + 1;
        int end = stat + (pageSize - 1);
        Service ca;
        try {
            //Query data from table Services
            String sQuery = "SELECT * FROM ("
                    + "SELECT *, ROW_NUMBER() OVER (ORDER BY id) AS RN FROM services"
                    + ") AS H "
                    + "where H.RN >= ? and H.RN <=?";
            con = db.getConnection();
            ps = con.prepareStatement(sQuery);
            ps.setInt(1, stat);
            ps.setInt(2, end);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String des = rs.getString("description");
                String picture = db.getResource() + rs.getString("image");
                String sortDes = rs.getString("shortDes");
                int type = rs.getInt("type");
                ca = new Service(id, title, des, picture, sortDes, type);
                returnList.add(ca);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            close.close(con, rs, ps);
        }
        return returnList;
    }

}
