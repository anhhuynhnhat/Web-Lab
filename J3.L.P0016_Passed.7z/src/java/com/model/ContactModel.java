/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.context.CloseConnection;
import com.context.DBContext;
import com.entity.Contact;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author anhhnse61724
 */
public class ContactModel {

    DBContext db = new DBContext();
    CloseConnection close = new CloseConnection();

    //get contact us
    public Contact getContact() throws Exception {
        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Contact ct = null;
        try {
            //Query data from ContactUs
            String sql = "Select TOP 1 * from ContactUS";
            connection = db.getConnection();
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                String address = rs.getString("address");
                String city = rs.getString("city");
                String country = rs.getString("country");
                String tel = rs.getString("tel");
                String email = rs.getString("email");
                String title = rs.getString("title");
                String content = rs.getString("content");
                ct = new Contact(address, city, country, tel, email, title, content);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            close.close(connection, rs, ps);
        }
        return ct;

    }

    //add new contact
    public Boolean addNewContact(String name, String email, String message) throws Exception {
        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            //Query insert data to Contact
            String sql = "INSERT INTO [Contact]([name],[email],[message]) VALUES (?,?,?)";
            connection = db.getConnection();
            ps = connection.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, message);
            ps.executeUpdate();

        } catch (Exception ex) {
            throw ex;
        } finally {
            close.close(connection, rs, ps);
        }
        return true;
    }

}
