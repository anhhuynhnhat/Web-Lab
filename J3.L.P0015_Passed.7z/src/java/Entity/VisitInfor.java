/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author chinhbpse04959
 */
public class VisitInfor {
    private String title;
    private String address;
    private String phoneHome;

    public VisitInfor(String title, String address, String phoneHome) {
        this.title = title;
        this.address = address;
        this.phoneHome = phoneHome;
    }

    public VisitInfor() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneHome() {
        return phoneHome;
    }

    public void setPhoneHome(String phoneHome) {
        this.phoneHome = phoneHome;
    }
    
}
