/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author chinhbpse04959
 */
public class FindCafe {
    private String address;
    private String tel;
    private String email;
    private String closed;
    private String opened1;
    private String opened2;

    public FindCafe() {
    }

    public FindCafe(String address, String tel, String email, String closed, String opened1, String opened2) {
        this.address = address;
        this.tel = tel;
        this.email = email;
        this.closed = closed;
        this.opened1 = opened1;
        this.opened2 = opened2;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClosed() {
        return closed;
    }

    public void setClosed(String closed) {
        this.closed = closed;
    }

    public String getOpened1() {
        return opened1;
    }

    public void setOpened1(String opened1) {
        this.opened1 = opened1;
    }

    public String getOpened2() {
        return opened2;
    }

    public void setOpened2(String opened2) {
        this.opened2 = opened2;
    }
    
    
}
