/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Entity.Cake;
import Entity.FindCafe;
import Entity.InforHome;
import Entity.VisitInfor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 *
 * @author chinhbpse04959
 */
public class GetData {
    public int numberOfItemOnPage = 5;

    
//        public String getImageLink() throws Exception {
//        String returnLink = "";
//        try {
//            InitialContext intContext = new InitialContext();
//            Context evnContext = (Context) intContext.lookup("java:comp/env");
//            returnLink = (String) evnContext.lookup("imageLink");
//        } catch (Exception e) {
//            throw e;
//        }
//        return returnLink;
//    }
    //get image's link from context file
    public String getImageLink() throws Exception {
        String returnLink = "";
        try {
            InitialContext intContext = new InitialContext();
            Context evnContext = (Context) intContext.lookup("java:comp/env");
            returnLink = (String) evnContext.lookup("imageLink");
        } catch (Exception e) {
            throw e;
        }
        return returnLink;
    }

    //get total pages
    public int getTotalPages() throws Exception {

        int totalPage = 0;
        int totalRecord = 0;
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        try {
            String query = "select count (*) as TotalRecord from Cake";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                totalRecord = rs.getInt("TotalRecord");
            }
            if (totalRecord % numberOfItemOnPage != 0) {
                totalPage = (totalRecord / numberOfItemOnPage) + 1;
            } else {
                totalPage = totalRecord / numberOfItemOnPage;
            }
            closeConnection(con, rs, ps);
            return totalPage;
        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }

    }

    //get dataList for each page
    public ArrayList<Cake> getDataList(int currentPage) throws Exception {

        int totalPage = 0;
        int totalRecord = 0;
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        ArrayList<Cake> returnList = new ArrayList<>();
        String localPicture = getImageLink();
        int start = (currentPage - 1) * numberOfItemOnPage + 1;
        int end = start + (numberOfItemOnPage -1);
        Cake cake;
        try {
            String query = "select * from (select ROW_NUMBER() over "
                    + "(order by (id) ASC) RN, *from Cake) a where a.RN between ? and ?";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            ps.setInt(1, start);
            ps.setInt(2, end);
            rs = ps.executeQuery();
            while (rs.next()) {
                String picture = "";
                picture = localPicture + rs.getString("picture");
                cake = new Cake(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getFloat("price"),
                        rs.getString("shortContent"),
                        rs.getString("content"),
                        picture);
                returnList.add(cake);
            }
            closeConnection(con, rs, ps);
            return returnList;

        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }

    }

    // get data for home page
    public InforHome getInforHomePage() throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        String localPicture = getImageLink();
        InforHome ih = null;
        try {
            String query = "select * from HomePage";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            String picture = "";
            while (rs.next()) {
                picture = localPicture + rs.getString("picture");
                ih = new InforHome(rs.getString("title"),
                        rs.getString("content"),
                        picture,
                        rs.getString("sign1"),
                        rs.getString("sign2"));
            }
            closeConnection(con, rs, ps);
            return ih;

        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    //get 2 cake for home page
    public ArrayList<Cake> getListCake() throws Exception {

        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        String localPicture = getImageLink();
        Cake cake = null;
        ArrayList<Cake> arr = new ArrayList<>();
        try {
            String query = "Select top 2 * from Cake";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                String picture = "";
                picture = localPicture + rs.getString("picture");
                cake = new Cake(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getFloat("price"),
                        rs.getString("shortContent"),
                        rs.getString("content"),
                        picture);
                arr.add(cake);
            }
            closeConnection(con, rs, ps);
            return arr;
        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    //get information for "Find Page"
    public FindCafe getInforFindPage() throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        FindCafe find = null;
        try {
            String query = "Select * from FindCafe";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                find = new FindCafe(rs.getString("address"),
                        rs.getString("tel"),
                        rs.getString("email"),
                        rs.getString("closed"),
                        rs.getString("opened1"),
                        rs.getString("opened2"));
            }
            closeConnection(con, rs, ps);
            return find;

        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    // get all infor of cake by id 
    public Cake getCakeByID(int id) throws Exception {

        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        String localPicture = getImageLink();
        Cake cake = null;
        try {
            String query = "Select * from Cake where id = ?";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            String picture = "";
            while (rs.next()) {
                picture = localPicture + rs.getString("picture");
                cake = new Cake(rs.getInt("id"),
                        rs.getString("title"),
                        rs.getFloat("price"),
                        rs.getString("shortContent"),
                        rs.getString("content"),
                        picture);
            }
            closeConnection(con, rs, ps);
            return cake;
        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    // get visit information for home page
    public VisitInfor getVisitInfor() throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        VisitInfor vi = null;
        try {
            String query = "Select * from VisitInfor";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            String picture = "";
            while (rs.next()) {
                vi = new VisitInfor(rs.getString("title"),
                        rs.getString("address"),
                        rs.getString("phoneHome"));
            }
            closeConnection(con, rs, ps);
            return vi;
        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    //handle close connect
    public void closeConnection(Connection con, ResultSet rs, PreparedStatement ps) throws Exception {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
            if (rs != null && !rs.isClosed()) {
                rs.close();
            }
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }

        } catch (Exception e) {
            throw e;
        }
    }

}
