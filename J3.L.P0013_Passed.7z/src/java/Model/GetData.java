/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Entity.FindPage;
import Entity.HomePicture;
import Entity.OpenCloseHour;
import Entity.Sushi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 *
 * @author anhhnse61724
 */
public class GetData {

    // get link to image from configure file (context.xml) 
    public int getNumberOfItemOnPage() throws Exception {
        int numberOfItemOnPage;
        try {
            InitialContext intContext = new InitialContext();
            Context evnContext = (Context) intContext.lookup("java:comp/env");
            numberOfItemOnPage = Integer.parseInt((String) evnContext.lookup("numberOfItemOnPage"));
        } catch (Exception e) {
            throw e;
        }
        return numberOfItemOnPage;
    }

    // get link to image from configure file (context.xml) 
    public String getImageLink() throws Exception {
        String returnLink = "";
        try {
            InitialContext intContext = new InitialContext();
            Context evnContext = (Context) intContext.lookup("java:comp/env");
            returnLink = (String) evnContext.lookup("imageLink");
        } catch (Exception e) {
            throw e;
        }
        return returnLink;
    }

    //get information of address, tel, email from FindPage
    public FindPage getInforFindPage() throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        FindPage find = null;
        try {
            String query = "Select * from FindPage";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                find = new FindPage(rs.getString("address"),
                        rs.getString("city"),
                        rs.getString("tel"),
                        rs.getString("email"));
            }
            closeConnection(con, rs, ps);
            return find;

        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    // get list open-close hours
    public ArrayList<OpenCloseHour> getOpenCloseHour() throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        OpenCloseHour hour = null;
        ArrayList<OpenCloseHour> listHour = new ArrayList<>();
        try {
            String query = "Select * from OpenCloseHour";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                hour = new OpenCloseHour(rs.getString("hour"));
                listHour.add(hour);
            }
            closeConnection(con, rs, ps);
            return listHour;

        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }
    //get total pages

    public int getTotalPages() throws Exception {
        int totalPage = 0;
        int totalRecord = 0;
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        int numberOfItemOnPage = getNumberOfItemOnPage();
        try {
            String query = "select count (*) as TotalRecord from sushi";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                totalRecord = rs.getInt("TotalRecord");
            }
            if (totalRecord % numberOfItemOnPage != 0) {
                totalPage = (totalRecord / numberOfItemOnPage) + 1;
            } else {
                totalPage = totalRecord / numberOfItemOnPage;
            }
            closeConnection(con, rs, ps);
            return totalPage;
        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }

    }

    public ArrayList<Sushi> getListSushi() throws Exception {

        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        String localPicture = getImageLink();
        Sushi sushi = null;
        ArrayList<Sushi> arr = new ArrayList<>();
        try {
            String query = "Select top 1 * from sushi";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                String picture = "";
                picture = localPicture + rs.getString("picture");
                sushi = new Sushi(rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("shortContent"),
                        rs.getString("Content"),
                        picture, rs.getFloat("price"));
                arr.add(sushi);
            }
            closeConnection(con, rs, ps);
            return arr;
        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    //get dataList for each page (3 sushi each page)
    public ArrayList<Sushi> getDataList(int currentPage) throws Exception {
        int totalPage = 0;
        int totalRecord = 0;
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        ArrayList<Sushi> returnList = new ArrayList<>();
        String localPicture = getImageLink();
        int numberOfItemOnPage = getNumberOfItemOnPage();
        int start = (currentPage - 1) * numberOfItemOnPage + 1;
        int end = start + (numberOfItemOnPage - 1);
        Sushi sushi;
        try {
            String query = "select * from (select ROW_NUMBER() over "
                    + "(order by (id) ASC) RN, * from sushi) a where a.RN between ? and ?";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            ps.setInt(1, start);
            ps.setInt(2, end);
            rs = ps.executeQuery();
            while (rs.next()) {
                String picture = "";
                picture = localPicture + rs.getString("picture");
                sushi = new Sushi(rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("shortContent"),
                        rs.getString("Content"),
                        picture, rs.getFloat("price"));
                sushi.setNumber(rs.getInt("RN"));
                returnList.add(sushi);
            }
            closeConnection(con, rs, ps);
            return returnList;

        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }

    }

    // get all infor of sushi by id 
    public Sushi getSushiByID(int id) throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        String localPicture = getImageLink();
        Sushi sushi = null;
        try {
            String query = "Select * from sushi where id = ?";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            String picture = "";
            while (rs.next()) {
                picture = localPicture + rs.getString("picture");
                sushi = new Sushi(rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("shortContent"),
                        rs.getString("Content"),
                        picture, rs.getFloat("price"));
            }
            closeConnection(con, rs, ps);
            return sushi;
        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    // get link of picture for home page
    public HomePicture getHomePicture() throws Exception {
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        String localPicture = getImageLink();
        HomePicture homePic = null;
        try {
            String query = "Select * from HomePic";
            Connect dbc = new Connect();
            con = dbc.getConnection();
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();
            String picture = "";
            while (rs.next()) {
                picture = localPicture + rs.getString("picture");
                homePic = new HomePicture(picture);

            }
            closeConnection(con, rs, ps);
            return homePic;
        } catch (Exception e) {
            closeConnection(con, rs, ps);
            throw e;
        }
    }

    //handle close connection
    public void closeConnection(Connection con, ResultSet rs, PreparedStatement ps) throws Exception {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
            if (rs != null && !rs.isClosed()) {
                rs.close();
            }
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }

        } catch (Exception e) {
            throw e;
        }
    }
}
