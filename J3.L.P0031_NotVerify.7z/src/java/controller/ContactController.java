package controller;

import entity.Content;
import model.ContentModel;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.MessageModel;

public class ContactController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            ContentModel cm = new ContentModel();
            Content c = cm.getContent();
            request.setAttribute("content", c);
            request.getRequestDispatcher("contact.jsp").forward(request, response);
        } catch (Exception e) {
            response.sendError(500);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
//            ContentModel cm= new ContentModel();
//            Content c= cm.getContent();
//            request.setAttribute("content", c);
//            request.getRequestDispatcher("contact.jsp").forward(request, response);
            String name = request.getParameter("mess_name");
            String email = request.getParameter("mess_email");
            String content = request.getParameter("mess_content");
            if (name == null || email == null || content == null) {
                request.setAttribute("error", "Please fill out all the fields");
            } else {
                name = name.trim();
                email = email.trim().toLowerCase();
                content = content.trim();
                if (name.isEmpty() || email.isEmpty() || content.isEmpty()) {
                    request.setAttribute("error", "Please fill out all the fields");
                } else {
//                    1a-z, 1-32 là khoang [a-z0-9_.]
                    if (email.matches("^[a-z][a-z0-9_.]{1,32}@[a-z0-9]{2,}([.][a-z0-9]{2,4}){1,2}$")) {
                        //insert
                        MessageModel model = new MessageModel();
                        model.insertMess(name, email, content);
                        request.setAttribute("notify", "Message sent!!!");
                    } else {
                        request.setAttribute("error", "Please check email format");
                    }
                }

            }
//            request.setAttribute("notify", notify);
            doGet(request, response);
//            request.getRequestDispatcher("contact.jsp").forward(request, response);

        } catch (Exception e) {
            response.sendError(500);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
