/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Article;
import model.ArticleModel;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SaleController extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            
            ArticleModel model = new ArticleModel();            
            int pagesize = 3;
            //get total page
            int totalPage = model.getTotalRows();
            //check if the record over capacity of page, then plus total page or not
            if (totalPage % pagesize == 0) {
                totalPage = totalPage / pagesize;
            } else {
                totalPage = totalPage / pagesize + 1;
            }
            String page = request.getParameter("page");
            
            page = (page == null || page.trim().isEmpty() || Integer.valueOf(page) > totalPage) ? "1" : page;
            int pagenumber = Integer.valueOf(page);
            
            request.setAttribute("Machines", model.getArticlesFromTo(pagenumber, pagesize));
            request.setAttribute("page", pagenumber);
            request.setAttribute("totalPage", totalPage);
            request.getRequestDispatcher("sale.jsp").forward(request, response);
        } catch (NumberFormatException nf) {
            response.sendError(404);
        } catch (Exception e) {
            System.out.println(e.getMessage().toString());
            response.sendError(500);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
