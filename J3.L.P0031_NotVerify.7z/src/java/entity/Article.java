
package entity;


public class Article {
    int id;
    String type,title, shortDescription, fulldescription,imglink;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getFulldescription() {
        return fulldescription;
    }

    public void setFulldescription(String fulldescription) {
        this.fulldescription = fulldescription;
    }

    public String getImglink() {
        return imglink;
    }

    public void setImglink(String imglink) {
        this.imglink = imglink;
    }

    public Article(int id, String type, String title, String shortDescription, String fulldescription, String imglink) {
        this.id = id;
        this.type = type;
        this.title = title;
        this.shortDescription = shortDescription;
        this.fulldescription = fulldescription;
        this.imglink = imglink;
    }

    public Article() {
    }
    
}
