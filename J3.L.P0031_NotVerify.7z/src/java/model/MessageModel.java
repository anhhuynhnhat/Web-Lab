/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import context.DBaccess;
import entity.Content;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.NamingException;

public class MessageModel {

    private final DBaccess db;

    public MessageModel() throws NamingException {
        db = new DBaccess();
    }

    public boolean insertMess(String name, String email, String content) throws SQLException, Exception {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = db.getConnection();
            String query = "insert into [Message]([name],[email],[Message])values(?,?,?)";

            ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, content);
            ps.executeUpdate();
            db.closeConnection(rs, ps, conn);
        } catch (Exception ex) {
            db.closeConnection(rs, ps, conn);
            throw ex;
        }
        return true;
    }

}
